Vial Support for Lyso1 LCK75.

Run the following command to build the firmware.
```sh
make lck75:vial
```

[QMK Settings](https://get.vial.today/changelog/release-0.4.html#qmk-settings) are disabled to save space.
